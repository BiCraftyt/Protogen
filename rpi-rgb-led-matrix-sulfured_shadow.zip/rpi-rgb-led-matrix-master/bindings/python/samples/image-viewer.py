#!/usr/bin/env python
#Aqui importo las librerias
import time
import sys

from rgbmatrix import RGBMatrix, RGBMatrixOptions
from PIL import Image

#Aqui defino la imagen para que se use durante el codigo entero
if len(sys.argv) < 2:
    sys.exit("Require an image argument")

image_path = sys.argv[1]

# Configuracion de las pantallas y hardware usado
options = RGBMatrixOptions()
options.rows = 32
options.chain_length = 2
options.parallel = 1
options.cols = 64
options.hardware_mapping = 'adafruit-hat'  # If you have an Adafruit HAT: 'adafruit-hat'
matrix = RGBMatrix(options = options)

#Aqui defino conceptos
MATRIX_WIDTH = options.cols
MATRIX_HEIGHT = options.rows

#Aqui le meto una conversion para que se pueda ver en las matrix
try:
 base_image = Image.open(image_path).convert("RGB")
except FileNotFoundError:
        print (f"Error: Imagen no encontrada bro {image_path}")
        sys.exit(1)

# Ma seguro que to estabin, si no se reajusta 
 
if base_image.size != (MATRIX_WIDTH, MATRIX_HEIGHT):
  print (f"Cambiando tamaño imagen, espera bro...")

#Aqui se ajusta para la pantalla y tambien se hace una copia de esta, se le da la vuelta y sale en la matrix, se hace un mirror
base_image = base_image.resize((MATRIX_WIDTH, MATRIX_HEIGHT),
 Image.Resampling.LANCZOS)
mirrored_image = base_image.transpose(Image.FLIP_LEFT_RIGHT)
canvas = matrix.CreateFrameCanvas()
canvas.SetImage(base_image, 0, 0)
canvas.SetImage(mirrored_image, MATRIX_WIDTH, 0)

canvas = matrix.SwapOnVSync(canvas)

#Comando simple para salir del programa
try:
    print("Press CTRL-C to stop.")
    while True:
        time.sleep(100)
except KeyboardInterrupt:
    sys.exit(0)
